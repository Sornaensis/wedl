---
schema: wedl/v0.3
kind: object
id: obj_3ZCC82GZAJ73JPXB3AP7HS7VB3
title: Sword of Gryffindor
domain: items.book-two
status: canonical
tags:
- book-two
- gryffindor
- basilisk
aliases: []
object_type: enchanted sword
capabilities:
- kills basilisk
initial_state:
  location:
    entity: loc_4NPBE4RK08T1Q7QA4F8DXCF964
  condition: delivered by Fawkes
---

# Sword of Gryffindor

Fawkes delivers the sword to Harry in the Chamber; Harry uses it against the basilisk.
