---
schema: wedl/v0.3
kind: object
id: obj_6FNF572D6F97HPJJT07RCBT76N
title: Mirror of Erised
domain: items.book-one
status: canonical
tags:
- book-one
- mirror
aliases: []
object_type: enchanted mirror
capabilities:
- reveals desire
- selects Stone seeker
initial_state:
  location:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  condition: hidden
---

# Mirror of Erised

Shows the viewer's deepest desire; it conceals the Stone from anyone seeking to use it.
