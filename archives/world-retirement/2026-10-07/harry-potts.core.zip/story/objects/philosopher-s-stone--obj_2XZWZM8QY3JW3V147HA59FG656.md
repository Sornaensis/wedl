---
schema: wedl/v0.3
kind: object
id: obj_2XZWZM8QY3JW3V147HA59FG656
title: Philosopher's Stone
domain: items.book-one
status: canonical
tags:
- book-one
- alchemy
- stone
aliases:
- Sorcerer's Stone
object_type: magical stone
capabilities:
- transmutes metal
- produces elixir
initial_state:
  condition: protected at Hogwarts
---

# Philosopher's Stone

Nicholas Flamel's alchemical stone; Quirrell seeks it to restore Voldemort.
