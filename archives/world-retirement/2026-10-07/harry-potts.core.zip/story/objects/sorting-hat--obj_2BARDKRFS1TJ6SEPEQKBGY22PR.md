---
schema: wedl/v0.3
kind: object
id: obj_2BARDKRFS1TJ6SEPEQKBGY22PR
title: Sorting Hat
domain: items.book-one
status: canonical
tags:
- hogwarts
- sorting
aliases: []
object_type: sentient hat
capabilities:
- sorts students
initial_state:
  location:
    entity: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
  condition: in use at Sorting
---

# Sorting Hat

Ancient hat that assigns new students to Hogwarts houses.
