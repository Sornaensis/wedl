---
schema: wedl/v0.3
kind: object
id: obj_60YGHPGSS90382S3X5N5XW5BCY
title: Nimbus Two Thousand
domain: items.book-one
status: canonical
tags:
- book-one
- quidditch
aliases:
- Nimbus 2000
object_type: racing broom
capabilities:
- flight
- quidditch
initial_state:
  condition: Harry's first broom
---

# Nimbus Two Thousand

McGonagall acquires this fast broom for Harry's first-year Quidditch role.
