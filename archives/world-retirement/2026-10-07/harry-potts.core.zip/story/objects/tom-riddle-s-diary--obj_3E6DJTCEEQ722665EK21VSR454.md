---
schema: wedl/v0.3
kind: object
id: obj_3E6DJTCEEQ722665EK21VSR454
title: Tom Riddle's Diary
domain: items.book-two
status: canonical
tags:
- book-two
- diary
- voldemort
aliases:
- the diary
object_type: cursed diary
capabilities:
- possesses reader
- stores memory
initial_state:
  condition: planted in Ginny's books
---

# Tom Riddle's Diary

Lucius Malfoy's planted diary; it drains Ginny and preserves a sixteen-year-old Tom Riddle.
