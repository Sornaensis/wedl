---
schema: wedl/v0.3
kind: object
id: obj_2JHZE6HNZMTC52SKATK5NA2G8G
title: Dobby's Sock
domain: items.book-two
status: canonical
tags:
- book-two
- dobby
- freedom
aliases: []
object_type: clothing
capabilities:
- frees house-elf
initial_state:
  condition: given to Lucius Malfoy
---

# Dobby's Sock

Harry hides a sock in Riddle's diary, causing Lucius to give clothing to Dobby and free him.
