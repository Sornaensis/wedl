---
schema: wedl/v0.3
kind: object
id: obj_3CY8WEEHC23VE83SRVPBEV5ZQW
title: Invisibility Cloak
domain: items.book-one
status: canonical
tags:
- book-one
- potter-family
aliases:
- Harry's cloak
object_type: magical garment
capabilities:
- conceals wearer
initial_state:
  condition: given to Harry
---

# Invisibility Cloak

Potter family cloak anonymously returned to Harry during his first Christmas at Hogwarts.
