---
schema: wedl/v0.3
kind: object
id: obj_28E29RXNVZAQT9J595EFDT89FA
title: Basilisk Fang
domain: items.book-two
status: canonical
tags:
- book-two
- basilisk
aliases: []
object_type: venomous fang
capabilities:
- destroys diary
initial_state:
  location:
    entity: loc_4NPBE4RK08T1Q7QA4F8DXCF964
  condition: available after basilisk defeat
---

# Basilisk Fang

Venom-bearing fang Harry uses to destroy Tom Riddle's diary.
