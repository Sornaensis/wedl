---
schema: wedl/v0.3
kind: character
id: char_7AP293AXR57YGHV4444DKCBB4P
title: Fawkes
domain: cast
status: canonical
tags:
- phoenix
- dumbledore
aliases: []
role: Phoenix
---

# Fawkes
