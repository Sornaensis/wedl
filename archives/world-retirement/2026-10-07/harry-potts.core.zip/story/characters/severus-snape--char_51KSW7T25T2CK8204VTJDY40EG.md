---
schema: wedl/v0.3
kind: character
id: char_51KSW7T25T2CK8204VTJDY40EG
title: Severus Snape
domain: cast
status: canonical
tags:
- hogwarts
- professor
- slytherin
aliases:
- Snape
role: Potions master
---

# Severus Snape
