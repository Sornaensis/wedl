---
schema: wedl/v0.3
kind: character
id: char_71H2XQP1HZMVR19PVZN1W6K0Q1
title: Dobby
domain: cast
status: canonical
tags:
- house-elf
- malfoy-household
aliases: []
role: House-elf
---

# Dobby
