---
schema: wedl/v0.3
kind: character
id: char_1Q12A9RCQ76MDS81PZ03440H6F
title: Gilderoy Lockhart
domain: cast
status: canonical
tags:
- hogwarts
- professor
- book-two
aliases:
- Lockhart
role: Defence Against the Dark Arts professor
---

# Gilderoy Lockhart
