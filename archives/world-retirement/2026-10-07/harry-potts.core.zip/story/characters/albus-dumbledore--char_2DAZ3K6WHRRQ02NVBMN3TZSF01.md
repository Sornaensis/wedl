---
schema: wedl/v0.3
kind: character
id: char_2DAZ3K6WHRRQ02NVBMN3TZSF01
title: Albus Dumbledore
domain: cast
status: canonical
tags:
- hogwarts
- headmaster
aliases:
- Dumbledore
role: Hogwarts headmaster
---

# Albus Dumbledore
