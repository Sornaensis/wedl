---
schema: wedl/v0.3
kind: character
id: char_7VQF2XFQG72XG32AD0PAGKXKJP
title: Rubeus Hagrid
domain: cast
status: canonical
tags:
- hogwarts
- gamekeeper
aliases:
- Hagrid
role: Keeper of Keys and Grounds
---

# Rubeus Hagrid
