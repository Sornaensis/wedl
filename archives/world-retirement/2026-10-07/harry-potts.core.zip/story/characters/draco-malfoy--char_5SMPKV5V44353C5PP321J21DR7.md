---
schema: wedl/v0.3
kind: character
id: char_5SMPKV5V44353C5PP321J21DR7
title: Draco Malfoy
domain: cast
status: canonical
tags:
- slytherin
- student
aliases:
- Draco
role: Hogwarts student
---

# Draco Malfoy
