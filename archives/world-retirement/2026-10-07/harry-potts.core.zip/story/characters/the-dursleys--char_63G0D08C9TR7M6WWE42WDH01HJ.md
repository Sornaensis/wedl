---
schema: wedl/v0.3
kind: character
id: char_63G0D08C9TR7M6WWE42WDH01HJ
title: The Dursleys
domain: cast
status: canonical
tags:
- muggle
- family
aliases:
- Vernon
- Petunia
- Dudley
role: Harry's guardians
---

# The Dursleys
