---
schema: wedl/v0.3
kind: character
id: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
title: Ginny Weasley
domain: cast
status: canonical
tags:
- gryffindor
- student
- weasley
aliases:
- Ginny
role: Hogwarts student
---

# Ginny Weasley
