---
schema: wedl/v0.3
kind: character
id: char_6JWY1MK97TKNATZM337VC3Y61A
title: Hermione Granger
domain: cast
status: canonical
tags:
- gryffindor
- student
aliases:
- Hermione
role: Hogwarts student
---

# Hermione Granger
