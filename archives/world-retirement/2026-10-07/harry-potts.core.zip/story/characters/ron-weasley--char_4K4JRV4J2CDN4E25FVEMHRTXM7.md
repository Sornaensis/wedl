---
schema: wedl/v0.3
kind: character
id: char_4K4JRV4J2CDN4E25FVEMHRTXM7
title: Ron Weasley
domain: cast
status: canonical
tags:
- gryffindor
- student
- weasley
aliases:
- Ron
role: Hogwarts student
---

# Ron Weasley
