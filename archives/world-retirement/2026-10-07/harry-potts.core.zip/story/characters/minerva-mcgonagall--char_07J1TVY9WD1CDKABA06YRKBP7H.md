---
schema: wedl/v0.3
kind: character
id: char_07J1TVY9WD1CDKABA06YRKBP7H
title: Minerva McGonagall
domain: cast
status: canonical
tags:
- hogwarts
- professor
- gryffindor
aliases:
- McGonagall
role: Deputy Headmistress
---

# Minerva McGonagall
