---
schema: wedl/v0.3
kind: character
id: char_0V9NP1H6YEE1X9TH62N13186NG
title: Lucius Malfoy
domain: cast
status: canonical
tags:
- malfoy
- death-eater
- book-two
aliases:
- Lucius
role: Wizarding aristocrat
---

# Lucius Malfoy
