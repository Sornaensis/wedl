---
schema: wedl/v0.3
kind: character
id: char_00FNTC1E3M5VMZD165VSWBMMX7
title: Neville Longbottom
domain: cast
status: canonical
tags:
- gryffindor
- student
aliases:
- Neville
role: Hogwarts student
---

# Neville Longbottom
