---
schema: wedl/v0.3
kind: character
id: char_67S6HHZQ86FEXV0X17JJZ1SY6V
title: Moaning Myrtle
domain: cast
status: canonical
tags:
- ghost
- hogwarts
aliases:
- Myrtle
role: Hogwarts ghost
---

# Moaning Myrtle
