---
schema: wedl/v0.3
kind: character
id: char_3JVZDAPEXCHMP0EHPD5P5YCWWB
title: Lord Voldemort
domain: cast
status: canonical
tags:
- dark-wizard
- antagonist
aliases:
- Voldemort
- You-Know-Who
role: Dark wizard
---

# Lord Voldemort
