---
schema: wedl/v0.3
kind: character
id: char_1YSHBR6EMQ1MQX2G6FPJSXK34B
title: Tom Riddle
domain: cast
status: canonical
tags:
- diary
- slytherin
- voldemort
aliases:
- Tom Marvolo Riddle
role: Diary memory
---

# Tom Riddle
