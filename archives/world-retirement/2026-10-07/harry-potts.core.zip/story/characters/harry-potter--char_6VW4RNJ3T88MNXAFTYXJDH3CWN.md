---
schema: wedl/v0.3
kind: character
id: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
title: Harry Potter
domain: cast
status: canonical
tags:
- gryffindor
- student
- protagonist
aliases:
- Harry
- The Boy Who Lived
role: Hogwarts student
initial_state:
  location:
    entity: loc_6FWCZHN05Q90ZSPND76C3TWN1H
---

# Harry Potter
