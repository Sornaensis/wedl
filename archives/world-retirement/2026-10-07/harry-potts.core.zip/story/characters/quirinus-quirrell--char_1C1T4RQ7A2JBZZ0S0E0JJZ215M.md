---
schema: wedl/v0.3
kind: character
id: char_1C1T4RQ7A2JBZZ0S0E0JJZ215M
title: Quirinus Quirrell
domain: cast
status: canonical
tags:
- hogwarts
- professor
- book-one-antagonist
aliases:
- Quirrell
role: Defence Against the Dark Arts professor
---

# Quirinus Quirrell
