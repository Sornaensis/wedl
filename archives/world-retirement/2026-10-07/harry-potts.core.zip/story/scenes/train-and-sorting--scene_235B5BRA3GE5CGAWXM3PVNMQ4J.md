---
schema: wedl/v0.3
kind: scene
id: scene_235B5BRA3GE5CGAWXM3PVNMQ4J
title: Train and Sorting
domain: book-one.scenes
status: closed
tags:
- book-one
- hogwarts
aliases: []
time:
  start:
    timeline: main
    tick: 30
  current:
    timeline: main
    tick: 31
  end:
    timeline: main
    tick: 31
location: loc_36YFCWAY20FF98HJ4AWJM30WRJ
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: student
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: student
- character: char_5SMPKV5V44353C5PP321J21DR7
  role: student
---

# Train and Sorting
