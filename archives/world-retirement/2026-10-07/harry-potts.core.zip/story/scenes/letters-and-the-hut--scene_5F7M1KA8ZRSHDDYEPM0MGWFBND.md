---
schema: wedl/v0.3
kind: scene
id: scene_5F7M1KA8ZRSHDDYEPM0MGWFBND
title: Letters and the Hut
domain: book-one.scenes
status: closed
tags:
- book-one
- discovery
aliases: []
time:
  start:
    timeline: main
    tick: 10
  current:
    timeline: main
    tick: 11
  end:
    timeline: main
    tick: 11
location: loc_6FWCZHN05Q90ZSPND76C3TWN1H
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: child
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: messenger
- character: char_63G0D08C9TR7M6WWE42WDH01HJ
  role: guardians
---

# Letters and the Hut
