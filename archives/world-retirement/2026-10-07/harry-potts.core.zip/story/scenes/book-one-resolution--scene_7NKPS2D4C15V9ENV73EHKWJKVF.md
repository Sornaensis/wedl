---
schema: wedl/v0.3
kind: scene
id: scene_7NKPS2D4C15V9ENV73EHKWJKVF
title: Book One Resolution
domain: book-one.scenes
status: closed
tags:
- book-one
- resolution
aliases: []
time:
  start:
    timeline: main
    tick: 90
  current:
    timeline: main
    tick: 91
  end:
    timeline: main
    tick: 91
location: loc_512ES0FTBVCNYRYBP6TAPDKZ16
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: patient
- character: char_2DAZ3K6WHRRQ02NVBMN3TZSF01
  role: headmaster
---

# Book One Resolution
