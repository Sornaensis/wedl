---
schema: wedl/v0.3
kind: scene
id: scene_7H274PYA3FNV3485X29KVFC9YQ
title: Halloween Troll
domain: book-one.scenes
status: closed
tags:
- book-one
- troll
aliases: []
time:
  start:
    timeline: main
    tick: 40
  current:
    timeline: main
    tick: 41
  end:
    timeline: main
    tick: 41
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: student
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: student
---

# Halloween Troll
