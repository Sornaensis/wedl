---
schema: wedl/v0.3
kind: scene
id: scene_0T89EXA7CRB9RAPFA4VFSDTDMX
title: Dobby's Warning
domain: book-two.scenes
status: closed
tags:
- book-two
- dobby
aliases: []
time:
  start:
    timeline: main
    tick: 100
  current:
    timeline: main
    tick: 101
  end:
    timeline: main
    tick: 101
location: loc_6FWCZHN05Q90ZSPND76C3TWN1H
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_71H2XQP1HZMVR19PVZN1W6K0Q1
  role: warning
---

# Dobby's Warning
