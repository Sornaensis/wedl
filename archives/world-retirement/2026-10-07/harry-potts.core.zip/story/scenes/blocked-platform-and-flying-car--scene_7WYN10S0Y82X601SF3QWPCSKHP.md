---
schema: wedl/v0.3
kind: scene
id: scene_7WYN10S0Y82X601SF3QWPCSKHP
title: Blocked Platform and Flying Car
domain: book-two.scenes
status: closed
tags:
- book-two
- arrival
aliases: []
time:
  start:
    timeline: main
    tick: 120
  current:
    timeline: main
    tick: 121
  end:
    timeline: main
    tick: 121
location: loc_36YFCWAY20FF98HJ4AWJM30WRJ
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: student
---

# Blocked Platform and Flying Car
