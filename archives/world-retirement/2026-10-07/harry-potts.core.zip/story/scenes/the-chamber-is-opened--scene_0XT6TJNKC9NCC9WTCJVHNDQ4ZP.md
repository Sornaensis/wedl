---
schema: wedl/v0.3
kind: scene
id: scene_0XT6TJNKC9NCC9WTCJVHNDQ4ZP
title: The Chamber Is Opened
domain: book-two.scenes
status: closed
tags:
- book-two
- chamber-of-secrets
- petrification
aliases: []
time:
  start:
    timeline: main
    tick: 130
  current:
    timeline: main
    tick: 131
  end:
    timeline: main
    tick: 131
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: witness
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: witness
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: witness
---

# The Chamber Is Opened
