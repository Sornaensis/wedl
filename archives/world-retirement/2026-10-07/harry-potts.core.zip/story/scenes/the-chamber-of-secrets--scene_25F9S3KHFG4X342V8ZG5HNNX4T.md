---
schema: wedl/v0.3
kind: scene
id: scene_25F9S3KHFG4X342V8ZG5HNNX4T
title: The Chamber of Secrets
domain: book-two.scenes
status: closed
tags:
- book-two
- chamber-of-secrets
- basilisk
- climax
aliases: []
time:
  start:
    timeline: main
    tick: 190
  current:
    timeline: main
    tick: 191
  end:
    timeline: main
    tick: 191
location: loc_4NPBE4RK08T1Q7QA4F8DXCF964
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: rescuer
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: possessed
- character: char_1YSHBR6EMQ1MQX2G6FPJSXK34B
  role: diary-memory
- character: char_7AP293AXR57YGHV4444DKCBB4P
  role: phoenix
---

# The Chamber of Secrets
