---
schema: wedl/v0.3
kind: scene
id: scene_0RJR3DJPTTGTMZR6EVDCA3G0X7
title: Mandrakes and the Final Clue
domain: book-two.scenes
status: closed
tags:
- book-two
- mandrakes
- petrification
aliases: []
time:
  start:
    timeline: main
    tick: 170
  current:
    timeline: main
    tick: 171
  end:
    timeline: main
    tick: 171
location: loc_512ES0FTBVCNYRYBP6TAPDKZ16
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: investigator
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: investigator
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: patient
---

# Mandrakes and the Final Clue
