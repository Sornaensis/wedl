---
schema: wedl/v0.3
kind: scene
id: scene_5GY1RN0Y9TYPBND2D3AT2ZB55J
title: Protection of the Stone
domain: book-one.scenes
status: closed
tags:
- book-one
- philosopher-stone
- climax
aliases: []
time:
  start:
    timeline: main
    tick: 80
  current:
    timeline: main
    tick: 81
  end:
    timeline: main
    tick: 81
location: loc_3R4557KV4VP0ZWZR22CVHXZKCX
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: student
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: student
- character: char_1C1T4RQ7A2JBZZ0S0E0JJZ215M
  role: intruder
---

# Protection of the Stone
