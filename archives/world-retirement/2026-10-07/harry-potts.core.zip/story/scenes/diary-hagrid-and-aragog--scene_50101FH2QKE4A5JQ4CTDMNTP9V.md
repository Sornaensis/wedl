---
schema: wedl/v0.3
kind: scene
id: scene_50101FH2QKE4A5JQ4CTDMNTP9V
title: Diary, Hagrid, and Aragog
domain: book-two.scenes
status: closed
tags:
- book-two
- diary
- aragog
aliases: []
time:
  start:
    timeline: main
    tick: 160
  current:
    timeline: main
    tick: 161
  end:
    timeline: main
    tick: 161
location: loc_6DQDGRW936HQRARKBA5Q6A5FCF
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: investigator
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: investigator
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: accused
---

# Diary, Hagrid, and Aragog
