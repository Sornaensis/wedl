---
schema: wedl/v0.3
kind: scene
id: scene_0RQ8KBGF35K558FMZDZQPNSXRE
title: Diagon Alley Introduction
domain: book-one.scenes
status: closed
tags:
- book-one
- wizarding-world
aliases: []
time:
  start:
    timeline: main
    tick: 20
  current:
    timeline: main
    tick: 21
  end:
    timeline: main
    tick: 21
location: loc_1NEN1Z27D4FR0EXCGVJ47MSVN8
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: newcomer
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: guide
---

# Diagon Alley Introduction
