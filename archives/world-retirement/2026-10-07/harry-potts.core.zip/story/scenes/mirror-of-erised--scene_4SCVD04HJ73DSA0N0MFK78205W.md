---
schema: wedl/v0.3
kind: scene
id: scene_4SCVD04HJ73DSA0N0MFK78205W
title: Mirror of Erised
domain: book-one.scenes
status: closed
tags:
- book-one
- mirror
aliases: []
time:
  start:
    timeline: main
    tick: 60
  current:
    timeline: main
    tick: 61
  end:
    timeline: main
    tick: 61
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_2DAZ3K6WHRRQ02NVBMN3TZSF01
  role: headmaster
---

# Mirror of Erised
