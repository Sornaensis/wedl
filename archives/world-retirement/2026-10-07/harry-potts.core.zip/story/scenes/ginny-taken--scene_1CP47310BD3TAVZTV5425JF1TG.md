---
schema: wedl/v0.3
kind: scene
id: scene_1CP47310BD3TAVZTV5425JF1TG
title: Ginny Taken
domain: book-two.scenes
status: closed
tags:
- book-two
- ginny
- chamber-of-secrets
aliases: []
time:
  start:
    timeline: main
    tick: 180
  current:
    timeline: main
    tick: 181
  end:
    timeline: main
    tick: 181
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: rescuer
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: rescuer
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: missing
- character: char_1Q12A9RCQ76MDS81PZ03440H6F
  role: professor
---

# Ginny Taken
