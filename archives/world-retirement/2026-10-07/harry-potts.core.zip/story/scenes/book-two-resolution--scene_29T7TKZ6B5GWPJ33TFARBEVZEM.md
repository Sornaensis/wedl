---
schema: wedl/v0.3
kind: scene
id: scene_29T7TKZ6B5GWPJ33TFARBEVZEM
title: Book Two Resolution
domain: book-two.scenes
status: closed
tags:
- book-two
- resolution
- dobby
aliases: []
time:
  start:
    timeline: main
    tick: 200
  current:
    timeline: main
    tick: 201
  end:
    timeline: main
    tick: 201
location: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: student
- character: char_71H2XQP1HZMVR19PVZN1W6K0Q1
  role: freed-elf
- character: char_0V9NP1H6YEE1X9TH62N13186NG
  role: master
---

# Book Two Resolution
