---
schema: wedl/v0.3
kind: scene
id: scene_0PVER30BDCBHWRX861NF92WZ9S
title: Detention in the Forbidden Forest
domain: book-one.scenes
status: closed
tags:
- book-one
- unicorn
- voldemort
aliases: []
time:
  start:
    timeline: main
    tick: 70
  current:
    timeline: main
    tick: 71
  end:
    timeline: main
    tick: 71
location: loc_6DQDGRW936HQRARKBA5Q6A5FCF
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: detention
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: keeper
- character: char_5SMPKV5V44353C5PP321J21DR7
  role: detention
- character: char_00FNTC1E3M5VMZD165VSWBMMX7
  role: detention
---

# Detention in the Forbidden Forest
