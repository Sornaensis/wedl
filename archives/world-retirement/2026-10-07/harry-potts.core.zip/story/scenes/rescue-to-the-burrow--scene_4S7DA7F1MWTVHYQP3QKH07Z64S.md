---
schema: wedl/v0.3
kind: scene
id: scene_4S7DA7F1MWTVHYQP3QKH07Z64S
title: Rescue to the Burrow
domain: book-two.scenes
status: closed
tags:
- book-two
- weasley
aliases: []
time:
  start:
    timeline: main
    tick: 110
  current:
    timeline: main
    tick: 111
  end:
    timeline: main
    tick: 111
location: loc_695R9QH8P4NA25G0MFCWRF4JT2
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: guest
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: rescuer
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: family
---

# Rescue to the Burrow
