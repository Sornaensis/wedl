---
schema: wedl/v0.3
kind: scene
id: scene_024CGVB46R5KXQRF9ZW5GF48JP
title: Dueling Club and Parseltongue
domain: book-two.scenes
status: closed
tags:
- book-two
- parseltongue
aliases: []
time:
  start:
    timeline: main
    tick: 140
  current:
    timeline: main
    tick: 141
  end:
    timeline: main
    tick: 141
location: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_5SMPKV5V44353C5PP321J21DR7
  role: student
- character: char_1Q12A9RCQ76MDS81PZ03440H6F
  role: professor
- character: char_51KSW7T25T2CK8204VTJDY40EG
  role: professor
---

# Dueling Club and Parseltongue
