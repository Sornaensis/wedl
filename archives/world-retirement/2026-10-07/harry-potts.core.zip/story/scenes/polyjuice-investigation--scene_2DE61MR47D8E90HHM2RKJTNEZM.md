---
schema: wedl/v0.3
kind: scene
id: scene_2DE61MR47D8E90HHM2RKJTNEZM
title: Polyjuice Investigation
domain: book-two.scenes
status: closed
tags:
- book-two
- polyjuice
- investigation
aliases: []
time:
  start:
    timeline: main
    tick: 150
  current:
    timeline: main
    tick: 151
  end:
    timeline: main
    tick: 151
location: loc_41NMJCQNZHZAKYVTVZ09JP30AV
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: investigator
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: investigator
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: investigator
---

# Polyjuice Investigation
