---
schema: wedl/v0.3
kind: scene
id: scene_7NE2KDR16P690TS2NNVJPS6AK6
title: The Boy Who Lived
domain: book-one.scenes
status: closed
tags:
- book-one
- prologue
aliases: []
time:
  start:
    timeline: main
    tick: 0
  current:
    timeline: main
    tick: 1
  end:
    timeline: main
    tick: 1
location: loc_6FWCZHN05Q90ZSPND76C3TWN1H
participants:
- character: char_2DAZ3K6WHRRQ02NVBMN3TZSF01
  role: headmaster
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: courier
---

# The Boy Who Lived
