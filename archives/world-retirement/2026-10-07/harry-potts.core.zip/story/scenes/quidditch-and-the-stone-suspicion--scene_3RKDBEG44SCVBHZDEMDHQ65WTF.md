---
schema: wedl/v0.3
kind: scene
id: scene_3RKDBEG44SCVBHZDEMDHQ65WTF
title: Quidditch and the Stone Suspicion
domain: book-one.scenes
status: closed
tags:
- book-one
- quidditch
- philosopher-stone
aliases: []
time:
  start:
    timeline: main
    tick: 50
  current:
    timeline: main
    tick: 51
  end:
    timeline: main
    tick: 51
location: loc_7JXTP4KTQK552N3THB4D29KYE0
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: seeker
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: witness
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: witness
- character: char_51KSW7T25T2CK8204VTJDY40EG
  role: professor
---

# Quidditch and the Stone Suspicion
