---
schema: wedl/v0.3
kind: relationship
id: rel_7YGB9VMBCHCVXFAZJXJJJ1WPVB
title: Harry's view of Voldemort
domain: relationships
status: canonical
tags:
- conflict
- fear
aliases: []
from: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
to: char_3JVZDAPEXCHMP0EHPD5P5YCWWB
relationship_kind: mortal enmity
transitions:
- id: rt_1PYHT181GKAW41BEFNFSQY661S
  time:
    timeline: main
    tick: 71
  relationship_status: active
  metrics:
    trust: -1.0
    affinity: -1.0
    fear: 0.9
    respect: -0.9
  facets:
  - parents' killer
  - returning threat
- id: rt_0JGNVRQGJQV760ZZNMCYZ08NGV
  time:
    timeline: main
    tick: 191
  relationship_status: active
  metrics:
    trust: -1.0
    affinity: -1.0
    fear: 0.8
    respect: -0.9
  facets:
  - recurring enemy
  - diary link
---

# Harry's view of Voldemort
