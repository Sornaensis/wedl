---
schema: wedl/v0.3
kind: relationship
id: rel_2PZXV8AND24GR1HDE4P1QNWWPB
title: Voldemort's view of Quirrell
domain: relationships
status: canonical
tags:
- possession
- control
aliases: []
from: char_3JVZDAPEXCHMP0EHPD5P5YCWWB
to: char_1C1T4RQ7A2JBZZ0S0E0JJZ215M
relationship_kind: possession
inverse: rel_7GBEQRTDB3N4HQ5RVNKRKTBQ75
transitions:
- id: rt_4D8FBZDV6AH5M2HZY9AXYES2P9
  time:
    timeline: main
    tick: 70
  relationship_status: active
  metrics:
    trust: 0.0
    affinity: -0.8
    fear: 0.0
    respect: -0.8
  facets:
  - agent
  - host
- id: rt_7EFVJJQ5ZQ49K860SSY3087CDC
  time:
    timeline: main
    tick: 81
  relationship_status: ended
  metrics:
    trust: 0.0
    affinity: -1.0
    fear: 0.0
    respect: -1.0
  facets:
  - dead host
---

# Voldemort's view of Quirrell
