---
schema: wedl/v0.3
kind: relationship
id: rel_6FZGXHFS3FNGYP56MJDDRK75MK
title: Ron's view of Harry
domain: relationships
status: canonical
tags:
- friendship
aliases: []
from: char_4K4JRV4J2CDN4E25FVEMHRTXM7
to: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
relationship_kind: friendship
inverse: rel_7EZQD1YA2155N2SAACX033EYB7
transitions:
- id: rt_4C5W0Q5N2CB42W5F4XT6BZXR1E
  time:
    timeline: main
    tick: 30
  relationship_status: active
  metrics:
    trust: 0.45
    affinity: 0.6
    fear: 0.0
    respect: 0.45
  facets:
  - new friend
---

# Ron's view of Harry
