---
schema: wedl/v0.3
kind: relationship
id: rel_583JG2VV2786FWGVX5452NWYFE
title: Harry's view of Dobby
domain: relationships
status: canonical
tags:
- alliance
aliases: []
from: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
to: char_71H2XQP1HZMVR19PVZN1W6K0Q1
relationship_kind: alliance
transitions:
- id: rt_2GWSRKN28BHNNXXW5N1ZNH27S0
  time:
    timeline: main
    tick: 191
    order: 1
  relationship_status: active
  metrics:
    trust: 0.8
    affinity: 0.75
    fear: 0.0
    respect: 0.7
  facets:
  - freed ally
---

# Harry's view of Dobby
