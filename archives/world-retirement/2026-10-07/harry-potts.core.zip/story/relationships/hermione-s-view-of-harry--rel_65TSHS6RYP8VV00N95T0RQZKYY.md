---
schema: wedl/v0.3
kind: relationship
id: rel_65TSHS6RYP8VV00N95T0RQZKYY
title: Hermione's view of Harry
domain: relationships
status: canonical
tags:
- friendship
aliases: []
from: char_6JWY1MK97TKNATZM337VC3Y61A
to: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
relationship_kind: friendship
inverse: rel_5X83H8G3Q7BQRZ0BAGE5EJ8J1R
transitions:
- id: rt_3DASC2WR08NE4HY62JDK6M3X8T
  time:
    timeline: main
    tick: 41
  relationship_status: active
  metrics:
    trust: 0.55
    affinity: 0.5
    fear: 0.0
    respect: 0.75
  facets:
  - friend after troll
---

# Hermione's view of Harry
