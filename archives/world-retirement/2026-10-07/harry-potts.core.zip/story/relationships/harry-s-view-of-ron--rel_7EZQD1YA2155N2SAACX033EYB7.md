---
schema: wedl/v0.3
kind: relationship
id: rel_7EZQD1YA2155N2SAACX033EYB7
title: Harry's view of Ron
domain: relationships
status: canonical
tags:
- friendship
aliases: []
from: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
to: char_4K4JRV4J2CDN4E25FVEMHRTXM7
relationship_kind: friendship
inverse: rel_6FZGXHFS3FNGYP56MJDDRK75MK
transitions:
- id: rt_574Q59T663C3GFEDQSZSCJC99Z
  time:
    timeline: main
    tick: 30
  relationship_status: active
  metrics:
    trust: 0.45
    affinity: 0.55
    fear: 0.0
    respect: 0.35
  facets:
  - new friend
- id: rt_4CDZF6WGCPCAQNEF9AWA1THP5J
  time:
    timeline: main
    tick: 81
  relationship_status: active
  metrics:
    trust: 0.9
    affinity: 0.9
    fear: 0.0
    respect: 0.8
  facets:
  - trusted friend
  - shared risk
---

# Harry's view of Ron
