---
schema: wedl/v0.3
kind: relationship
id: rel_7E6XWHNGXNFRG7ATAG1ZXG36QJ
title: Harry's view of Dumbledore
domain: relationships
status: canonical
tags:
- mentor
aliases: []
from: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
to: char_2DAZ3K6WHRRQ02NVBMN3TZSF01
relationship_kind: mentor
transitions:
- id: rt_2S0254RNVTK6N2ASNPG9VF9NVS
  time:
    timeline: main
    tick: 60
  relationship_status: active
  metrics:
    trust: 0.65
    affinity: 0.2
    fear: 0.0
    respect: 0.9
  facets:
  - authority
  - guide
- id: rt_3TFQN70PNVTBHGSN6ENK0PTKEQ
  time:
    timeline: main
    tick: 191
  relationship_status: active
  metrics:
    trust: 0.75
    affinity: 0.35
    fear: 0.0
    respect: 0.95
  facets:
  - mentor
  - trusted headmaster
---

# Harry's view of Dumbledore
