---
schema: wedl/v0.3
kind: relationship
id: rel_7GBEQRTDB3N4HQ5RVNKRKTBQ75
title: Quirrell's view of Voldemort
domain: relationships
status: canonical
tags:
- possession
- fear
aliases: []
from: char_1C1T4RQ7A2JBZZ0S0E0JJZ215M
to: char_3JVZDAPEXCHMP0EHPD5P5YCWWB
relationship_kind: dependence
inverse: rel_2PZXV8AND24GR1HDE4P1QNWWPB
transitions:
- id: rt_5DHQDNP48T57H144S658BGSXEJ
  time:
    timeline: main
    tick: 70
  relationship_status: active
  metrics:
    trust: 0.1
    affinity: -0.8
    fear: 1.0
    respect: 0.2
  facets:
  - possessed
  - terrified follower
---

# Quirrell's view of Voldemort
