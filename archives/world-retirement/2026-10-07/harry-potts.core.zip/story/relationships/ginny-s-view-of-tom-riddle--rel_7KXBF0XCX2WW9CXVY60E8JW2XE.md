---
schema: wedl/v0.3
kind: relationship
id: rel_7KXBF0XCX2WW9CXVY60E8JW2XE
title: Ginny's view of Tom Riddle
domain: relationships
status: canonical
tags:
- possession
- coercion
aliases: []
from: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
to: char_1YSHBR6EMQ1MQX2G6FPJSXK34B
relationship_kind: coercive attachment
inverse: rel_6SSCR10F183V8ZEFTHP287M7DX
transitions:
- id: rt_09WT1RAZEJHBXQTN8QJ22NDSRW
  time:
    timeline: main
    tick: 110
  relationship_status: active
  metrics:
    trust: 0.7
    affinity: 0.45
    fear: 0.1
    respect: 0.3
  facets:
  - diary confidant
- id: rt_731SKVCMAHWXASJXNEFN1J6GMF
  time:
    timeline: main
    tick: 191
  relationship_status: ended
  metrics:
    trust: -1.0
    affinity: -1.0
    fear: 1.0
    respect: -1.0
  facets:
  - destroyed possessor
---

# Ginny's view of Tom Riddle
