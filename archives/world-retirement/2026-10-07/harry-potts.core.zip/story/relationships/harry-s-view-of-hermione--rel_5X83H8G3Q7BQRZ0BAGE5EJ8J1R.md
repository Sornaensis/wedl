---
schema: wedl/v0.3
kind: relationship
id: rel_5X83H8G3Q7BQRZ0BAGE5EJ8J1R
title: Harry's view of Hermione
domain: relationships
status: canonical
tags:
- friendship
aliases: []
from: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
to: char_6JWY1MK97TKNATZM337VC3Y61A
relationship_kind: friendship
inverse: rel_65TSHS6RYP8VV00N95T0RQZKYY
transitions:
- id: rt_5CA7SFT05953M8RBG8VDFWM3J5
  time:
    timeline: main
    tick: 41
  relationship_status: active
  metrics:
    trust: 0.55
    affinity: 0.5
    fear: 0.0
    respect: 0.7
  facets:
  - friend after troll
- id: rt_2YT77AA0YQDWJJ8FF9QB2S33Q2
  time:
    timeline: main
    tick: 191
  relationship_status: active
  metrics:
    trust: 0.9
    affinity: 0.85
    fear: 0.0
    respect: 0.95
  facets:
  - trusted investigator
---

# Harry's view of Hermione
