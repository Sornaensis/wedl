---
schema: wedl/v0.3
kind: relationship
id: rel_6SSCR10F183V8ZEFTHP287M7DX
title: Tom Riddle's view of Ginny
domain: relationships
status: canonical
tags:
- possession
- coercion
aliases: []
from: char_1YSHBR6EMQ1MQX2G6FPJSXK34B
to: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
relationship_kind: possession
inverse: rel_7KXBF0XCX2WW9CXVY60E8JW2XE
transitions:
- id: rt_7C6HBSQ59Y4V9KWB9KZH1NBQJT
  time:
    timeline: main
    tick: 110
  relationship_status: active
  metrics:
    trust: 0.0
    affinity: -0.6
    fear: 0.0
    respect: -0.8
  facets:
  - instrument
  - life source
---

# Tom Riddle's view of Ginny
