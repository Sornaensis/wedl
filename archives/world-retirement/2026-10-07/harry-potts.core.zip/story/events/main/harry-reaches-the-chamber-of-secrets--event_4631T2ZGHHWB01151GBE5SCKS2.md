---
schema: wedl/v0.3
kind: event
id: event_4631T2ZGHHWB01151GBE5SCKS2
title: Harry reaches the Chamber of Secrets
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 190
  order: 90
location: loc_4NPBE4RK08T1Q7QA4F8DXCF964
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: rescuer
- character: char_7AP293AXR57YGHV4444DKCBB4P
  role: ally
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_4NPBE4RK08T1Q7QA4F8DXCF964
  id: effect_00000000000000000000000040
- target: char_7AP293AXR57YGHV4444DKCBB4P
  key: location
  operation: set
  value:
    entity: loc_4NPBE4RK08T1Q7QA4F8DXCF964
  id: effect_00000000000000000000000041
---

# Harry reaches the Chamber of Secrets
