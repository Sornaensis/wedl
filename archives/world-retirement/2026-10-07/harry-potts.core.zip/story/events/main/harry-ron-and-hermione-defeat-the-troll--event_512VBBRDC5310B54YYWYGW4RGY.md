---
schema: wedl/v0.3
kind: event
id: event_512VBBRDC5310B54YYWYGW4RGY
title: Harry, Ron, and Hermione Defeat the Troll
domain: book-one.events
status: canonical
tags:
- book-one
- troll
- friendship
aliases: []
time:
  timeline: main
  tick: 41
  order: 0
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: student
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: student
causes: []
related_story_points: []
effects: []
---

# Harry, Ron, and Hermione Defeat the Troll
