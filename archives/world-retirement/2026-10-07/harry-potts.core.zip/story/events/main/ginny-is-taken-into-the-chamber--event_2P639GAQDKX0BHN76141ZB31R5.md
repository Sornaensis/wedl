---
schema: wedl/v0.3
kind: event
id: event_2P639GAQDKX0BHN76141ZB31R5
title: Ginny Is Taken into the Chamber
domain: book-two.events
status: canonical
tags:
- book-two
- ginny
- chamber-of-secrets
aliases: []
time:
  timeline: main
  tick: 181
  order: 0
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: victim
- character: char_1YSHBR6EMQ1MQX2G6FPJSXK34B
  role: abductor
causes:
- event_5DRACWWMAZR7SMAQX12R18CTC5
related_story_points: []
effects: []
---

# Ginny Is Taken into the Chamber
