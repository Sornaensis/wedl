---
schema: wedl/v0.3
kind: event
id: event_7KV9MJVFVWMYH6Q2BYERH00D3K
title: The Polyjuice investigation begins in Gryffindor Tower
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 150
  order: 90
location: loc_41NMJCQNZHZAKYVTVZ09JP30AV
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: investigator
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: investigator
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: investigator
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_41NMJCQNZHZAKYVTVZ09JP30AV
  id: effect_00000000000000000000000030
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_41NMJCQNZHZAKYVTVZ09JP30AV
  id: effect_00000000000000000000000031
- target: char_6JWY1MK97TKNATZM337VC3Y61A
  key: location
  operation: set
  value:
    entity: loc_41NMJCQNZHZAKYVTVZ09JP30AV
  id: effect_00000000000000000000000032
---

# The Polyjuice investigation begins in Gryffindor Tower
