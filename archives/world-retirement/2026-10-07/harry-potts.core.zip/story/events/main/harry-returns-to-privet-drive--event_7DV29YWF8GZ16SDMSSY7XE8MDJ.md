---
schema: wedl/v0.3
kind: event
id: event_7DV29YWF8GZ16SDMSSY7XE8MDJ
title: Harry returns to Privet Drive
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 100
  order: 90
location: loc_6FWCZHN05Q90ZSPND76C3TWN1H
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: returning student
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_6FWCZHN05Q90ZSPND76C3TWN1H
  id: effect_00000000000000000000000022
---

# Harry returns to Privet Drive
