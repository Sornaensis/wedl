---
schema: wedl/v0.3
kind: event
id: event_0SRAJRCDYP2X5EYRCE0RTDABT6
title: The Weasley rescue reaches the Burrow
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 110
  order: 90
location: loc_695R9QH8P4NA25G0MFCWRF4JT2
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: rescued guest
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: rescuer
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: family
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_695R9QH8P4NA25G0MFCWRF4JT2
  id: effect_00000000000000000000000023
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_695R9QH8P4NA25G0MFCWRF4JT2
  id: effect_00000000000000000000000024
- target: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  key: location
  operation: set
  value:
    entity: loc_695R9QH8P4NA25G0MFCWRF4JT2
  id: effect_00000000000000000000000025
---

# The Weasley rescue reaches the Burrow
