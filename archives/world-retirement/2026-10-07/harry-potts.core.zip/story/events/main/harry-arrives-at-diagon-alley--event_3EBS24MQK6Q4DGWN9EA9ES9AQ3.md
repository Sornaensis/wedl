---
schema: wedl/v0.3
kind: event
id: event_3EBS24MQK6Q4DGWN9EA9ES9AQ3
title: Harry arrives at Diagon Alley
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 20
  order: 90
location: loc_1NEN1Z27D4FR0EXCGVJ47MSVN8
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: arrival
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_1NEN1Z27D4FR0EXCGVJ47MSVN8
  id: effect_00000000000000000000000001
---

# Harry arrives at Diagon Alley
