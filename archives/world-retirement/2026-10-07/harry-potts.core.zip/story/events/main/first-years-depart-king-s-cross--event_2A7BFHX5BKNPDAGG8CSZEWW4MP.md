---
schema: wedl/v0.3
kind: event
id: event_2A7BFHX5BKNPDAGG8CSZEWW4MP
title: First-years depart King's Cross
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 30
  order: 90
location: loc_36YFCWAY20FF98HJ4AWJM30WRJ
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: departing student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: departing student
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: departing student
- character: char_5SMPKV5V44353C5PP321J21DR7
  role: departing student
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_36YFCWAY20FF98HJ4AWJM30WRJ
  id: effect_00000000000000000000000002
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_36YFCWAY20FF98HJ4AWJM30WRJ
  id: effect_00000000000000000000000003
- target: char_6JWY1MK97TKNATZM337VC3Y61A
  key: location
  operation: set
  value:
    entity: loc_36YFCWAY20FF98HJ4AWJM30WRJ
  id: effect_00000000000000000000000004
- target: char_5SMPKV5V44353C5PP321J21DR7
  key: location
  operation: set
  value:
    entity: loc_36YFCWAY20FF98HJ4AWJM30WRJ
  id: effect_00000000000000000000000005
---

# First-years depart King's Cross
