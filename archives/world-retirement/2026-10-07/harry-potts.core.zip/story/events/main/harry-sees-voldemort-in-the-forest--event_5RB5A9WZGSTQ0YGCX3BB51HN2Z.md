---
schema: wedl/v0.3
kind: event
id: event_5RB5A9WZGSTQ0YGCX3BB51HN2Z
title: Harry Sees Voldemort in the Forest
domain: book-one.events
status: canonical
tags:
- book-one
- voldemort
- unicorn
aliases: []
time:
  timeline: main
  tick: 71
  order: 0
location: loc_6DQDGRW936HQRARKBA5Q6A5FCF
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: witness
- character: char_3JVZDAPEXCHMP0EHPD5P5YCWWB
  role: presence
causes: []
related_story_points: []
effects: []
---

# Harry Sees Voldemort in the Forest
