---
schema: wedl/v0.3
kind: event
id: event_2BNFQSE8R1AS7BJNX68XVGYKK7
title: Harry and Ron enter the Forbidden Forest
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 160
  order: 90
location: loc_6DQDGRW936HQRARKBA5Q6A5FCF
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: investigator
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: investigator
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: host
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_6DQDGRW936HQRARKBA5Q6A5FCF
  id: effect_00000000000000000000000033
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_6DQDGRW936HQRARKBA5Q6A5FCF
  id: effect_00000000000000000000000034
- target: char_7VQF2XFQG72XG32AD0PAGKXKJP
  key: location
  operation: set
  value:
    entity: loc_6DQDGRW936HQRARKBA5Q6A5FCF
  id: effect_00000000000000000000000035
---

# Harry and Ron enter the Forbidden Forest
