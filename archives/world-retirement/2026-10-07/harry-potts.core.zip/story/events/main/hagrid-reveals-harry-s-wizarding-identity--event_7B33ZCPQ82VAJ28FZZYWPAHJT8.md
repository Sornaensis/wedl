---
schema: wedl/v0.3
kind: event
id: event_7B33ZCPQ82VAJ28FZZYWPAHJT8
title: Hagrid Reveals Harry's Wizarding Identity
domain: book-one.events
status: canonical
tags:
- book-one
- identity
aliases: []
time:
  timeline: main
  tick: 11
  order: 0
location: loc_6FWCZHN05Q90ZSPND76C3TWN1H
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: recipient
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: messenger
causes:
- event_4K4X4X8DFW53GSX768Z236AK5C
related_story_points: []
effects: []
---

# Hagrid Reveals Harry's Wizarding Identity
