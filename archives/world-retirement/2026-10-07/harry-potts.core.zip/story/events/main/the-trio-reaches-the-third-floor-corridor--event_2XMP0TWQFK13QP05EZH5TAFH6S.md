---
schema: wedl/v0.3
kind: event
id: event_2XMP0TWQFK13QP05EZH5TAFH6S
title: The trio reaches the third-floor corridor
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 80
  order: 90
location: loc_3R4557KV4VP0ZWZR22CVHXZKCX
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: investigator
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: investigator
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: investigator
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_3R4557KV4VP0ZWZR22CVHXZKCX
  id: effect_00000000000000000000000018
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_3R4557KV4VP0ZWZR22CVHXZKCX
  id: effect_00000000000000000000000019
- target: char_6JWY1MK97TKNATZM337VC3Y61A
  key: location
  operation: set
  value:
    entity: loc_3R4557KV4VP0ZWZR22CVHXZKCX
  id: effect_00000000000000000000000020
---

# The trio reaches the third-floor corridor
