---
schema: wedl/v0.3
kind: event
id: event_0BRRPQ3NNVAAPQ4MMCBKCHFYXK
title: The Chamber rescue returns to the Great Hall
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 200
  order: 90
location: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: rescuer
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: rescued student
- character: char_71H2XQP1HZMVR19PVZN1W6K0Q1
  role: freed elf
- character: char_0V9NP1H6YEE1X9TH62N13186NG
  role: visitor
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
  id: effect_00000000000000000000000042
- target: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  key: location
  operation: set
  value:
    entity: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
  id: effect_00000000000000000000000043
- target: char_71H2XQP1HZMVR19PVZN1W6K0Q1
  key: location
  operation: set
  value:
    entity: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
  id: effect_00000000000000000000000044
- target: char_0V9NP1H6YEE1X9TH62N13186NG
  key: location
  operation: set
  value:
    entity: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
  id: effect_00000000000000000000000045
---

# The Chamber rescue returns to the Great Hall
