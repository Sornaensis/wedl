---
schema: wedl/v0.3
kind: event
id: event_24JDEK0DW8EYABNJGPPWWBFJ2M
title: Detention party enters the Forbidden Forest
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 70
  order: 90
location: loc_6DQDGRW936HQRARKBA5Q6A5FCF
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: detention
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: escort
- character: char_5SMPKV5V44353C5PP321J21DR7
  role: detention
- character: char_00FNTC1E3M5VMZD165VSWBMMX7
  role: detention
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_6DQDGRW936HQRARKBA5Q6A5FCF
  id: effect_00000000000000000000000010
- target: char_7VQF2XFQG72XG32AD0PAGKXKJP
  key: location
  operation: set
  value:
    entity: loc_6DQDGRW936HQRARKBA5Q6A5FCF
  id: effect_00000000000000000000000011
- target: char_5SMPKV5V44353C5PP321J21DR7
  key: location
  operation: set
  value:
    entity: loc_6DQDGRW936HQRARKBA5Q6A5FCF
  id: effect_00000000000000000000000012
- target: char_00FNTC1E3M5VMZD165VSWBMMX7
  key: location
  operation: set
  value:
    entity: loc_6DQDGRW936HQRARKBA5Q6A5FCF
  id: effect_00000000000000000000000013
---

# Detention party enters the Forbidden Forest
