---
schema: wedl/v0.3
kind: event
id: event_5DRACWWMAZR7SMAQX12R18CTC5
title: The Chamber of Secrets Is Reopened
domain: book-two.events
status: canonical
tags:
- book-two
- chamber-of-secrets
aliases: []
time:
  timeline: main
  tick: 131
  order: 0
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: possessed
- character: char_1YSHBR6EMQ1MQX2G6FPJSXK34B
  role: influence
causes: []
related_story_points: []
effects: []
---

# The Chamber of Secrets Is Reopened
