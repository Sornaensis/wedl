---
schema: wedl/v0.3
kind: event
id: event_4K4X4X8DFW53GSX768Z236AK5C
title: Harry Survives Voldemort's Attack
domain: book-one.events
status: canonical
tags:
- book-one
- backstory
aliases: []
time:
  timeline: main
  tick: 0
  order: 0
location: loc_6FWCZHN05Q90ZSPND76C3TWN1H
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: survivor
- character: char_3JVZDAPEXCHMP0EHPD5P5YCWWB
  role: attacker
causes: []
related_story_points: []
effects: []
---

# Harry Survives Voldemort's Attack
