---
schema: wedl/v0.3
kind: event
id: event_6RCFM8J9ANM4B9DPMBSE36W60A
title: Harry and Ron depart King's Cross
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 120
  order: 90
location: loc_36YFCWAY20FF98HJ4AWJM30WRJ
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: departing student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: departing student
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_36YFCWAY20FF98HJ4AWJM30WRJ
  id: effect_00000000000000000000000026
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_36YFCWAY20FF98HJ4AWJM30WRJ
  id: effect_00000000000000000000000027
---

# Harry and Ron depart King's Cross
