---
schema: wedl/v0.3
kind: event
id: event_5621ZFV9K52VTN068NBZYYMRS4
title: Harry and Ron return from the Forbidden Forest
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 162
  order: 90
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: returning student
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: returning student
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000037
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000038
---

# Harry and Ron return from the Forbidden Forest
