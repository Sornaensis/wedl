---
schema: wedl/v0.3
kind: event
id: event_4Z948KBFTRWMNCA2B8CPBHAXTA
title: Dobby Warns Harry Away from Hogwarts
domain: book-two.events
status: canonical
tags:
- book-two
- dobby
aliases: []
time:
  timeline: main
  tick: 101
  order: 0
location: loc_6FWCZHN05Q90ZSPND76C3TWN1H
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: recipient
- character: char_71H2XQP1HZMVR19PVZN1W6K0Q1
  role: warning
causes: []
related_story_points: []
effects: []
---

# Dobby Warns Harry Away from Hogwarts
