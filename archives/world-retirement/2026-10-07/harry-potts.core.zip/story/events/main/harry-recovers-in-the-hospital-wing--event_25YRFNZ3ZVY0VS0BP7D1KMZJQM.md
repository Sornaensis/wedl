---
schema: wedl/v0.3
kind: event
id: event_25YRFNZ3ZVY0VS0BP7D1KMZJQM
title: Harry recovers in the Hospital Wing
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 90
  order: 90
location: loc_512ES0FTBVCNYRYBP6TAPDKZ16
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: patient
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_512ES0FTBVCNYRYBP6TAPDKZ16
  id: effect_00000000000000000000000021
---

# Harry recovers in the Hospital Wing
