---
schema: wedl/v0.3
kind: event
id: event_1GS6YJ3JP8EGMHC4C396BYHW3B
title: Detention party returns to Hogwarts
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 72
  order: 90
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: returning student
- character: char_7VQF2XFQG72XG32AD0PAGKXKJP
  role: escort
- character: char_5SMPKV5V44353C5PP321J21DR7
  role: returning student
- character: char_00FNTC1E3M5VMZD165VSWBMMX7
  role: returning student
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000014
- target: char_7VQF2XFQG72XG32AD0PAGKXKJP
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000015
- target: char_5SMPKV5V44353C5PP321J21DR7
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000016
- target: char_00FNTC1E3M5VMZD165VSWBMMX7
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000017
---

# Detention party returns to Hogwarts
