---
schema: wedl/v0.3
kind: event
id: event_3379SD158CEYAYBD8P964J5MP7
title: Hermione Is Petrified
domain: book-two.events
status: canonical
tags:
- book-two
- petrification
- clue
aliases: []
time:
  timeline: main
  tick: 161
  order: 0
location: loc_512ES0FTBVCNYRYBP6TAPDKZ16
participants:
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: victim
causes:
- event_5DRACWWMAZR7SMAQX12R18CTC5
related_story_points: []
effects: []
---

# Hermione Is Petrified
