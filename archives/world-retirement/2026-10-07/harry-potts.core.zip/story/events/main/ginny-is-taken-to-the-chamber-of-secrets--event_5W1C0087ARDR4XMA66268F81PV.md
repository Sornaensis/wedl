---
schema: wedl/v0.3
kind: event
id: event_5W1C0087ARDR4XMA66268F81PV
title: Ginny is taken to the Chamber of Secrets
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 181
  order: 90
location: loc_4NPBE4RK08T1Q7QA4F8DXCF964
participants:
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: captive
causes: []
related_story_points: []
effects:
- target: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  key: location
  operation: set
  value:
    entity: loc_4NPBE4RK08T1Q7QA4F8DXCF964
  id: effect_00000000000000000000000039
---

# Ginny is taken to the Chamber of Secrets
