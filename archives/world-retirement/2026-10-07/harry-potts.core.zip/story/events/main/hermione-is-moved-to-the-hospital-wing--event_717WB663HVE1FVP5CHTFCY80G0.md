---
schema: wedl/v0.3
kind: event
id: event_717WB663HVE1FVP5CHTFCY80G0
title: Hermione is moved to the Hospital Wing
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 161
  order: 90
location: loc_512ES0FTBVCNYRYBP6TAPDKZ16
participants:
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: patient
causes: []
related_story_points: []
effects:
- target: char_6JWY1MK97TKNATZM337VC3Y61A
  key: location
  operation: set
  value:
    entity: loc_512ES0FTBVCNYRYBP6TAPDKZ16
  id: effect_00000000000000000000000036
---

# Hermione is moved to the Hospital Wing
