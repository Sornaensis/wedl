---
schema: wedl/v0.3
kind: event
id: event_2Z1GJK9MSGC4D0CQT37ZKJC8BG
title: First-years arrive at Hogwarts
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 31
  order: 90
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: arrival
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: arrival
- character: char_6JWY1MK97TKNATZM337VC3Y61A
  role: arrival
- character: char_5SMPKV5V44353C5PP321J21DR7
  role: arrival
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000006
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000007
- target: char_6JWY1MK97TKNATZM337VC3Y61A
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000008
- target: char_5SMPKV5V44353C5PP321J21DR7
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000009
---

# First-years arrive at Hogwarts
