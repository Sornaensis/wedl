---
schema: wedl/v0.3
kind: event
id: event_35162931H4PE68PZDYFY5QQVY7
title: Quirrell Is Revealed as Voldemort's Agent
domain: book-one.events
status: canonical
tags:
- book-one
- quirrell
- voldemort
aliases: []
time:
  timeline: main
  tick: 81
  order: 0
location: loc_3R4557KV4VP0ZWZR22CVHXZKCX
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: opponent
- character: char_1C1T4RQ7A2JBZZ0S0E0JJZ215M
  role: agent
- character: char_3JVZDAPEXCHMP0EHPD5P5YCWWB
  role: possessor
causes:
- event_5RB5A9WZGSTQ0YGCX3BB51HN2Z
related_story_points: []
effects: []
---

# Quirrell Is Revealed as Voldemort's Agent
