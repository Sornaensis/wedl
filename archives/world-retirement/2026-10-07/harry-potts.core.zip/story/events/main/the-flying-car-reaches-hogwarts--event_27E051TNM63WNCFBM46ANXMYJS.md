---
schema: wedl/v0.3
kind: event
id: event_27E051TNM63WNCFBM46ANXMYJS
title: The flying car reaches Hogwarts
domain: timeline.whereabouts
status: canonical
tags: []
aliases: []
time:
  timeline: main
  tick: 121
  order: 90
location: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: arrival
- character: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  role: arrival
causes: []
related_story_points: []
effects:
- target: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000028
- target: char_4K4JRV4J2CDN4E25FVEMHRTXM7
  key: location
  operation: set
  value:
    entity: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
  id: effect_00000000000000000000000029
---

# The flying car reaches Hogwarts
