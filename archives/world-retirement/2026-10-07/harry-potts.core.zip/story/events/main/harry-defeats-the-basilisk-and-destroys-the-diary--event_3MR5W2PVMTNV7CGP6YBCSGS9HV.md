---
schema: wedl/v0.3
kind: event
id: event_3MR5W2PVMTNV7CGP6YBCSGS9HV
title: Harry Defeats the Basilisk and Destroys the Diary
domain: book-two.events
status: canonical
tags:
- book-two
- basilisk
- diary
- climax
aliases: []
time:
  timeline: main
  tick: 191
  order: 0
location: loc_4NPBE4RK08T1Q7QA4F8DXCF964
participants:
- character: char_6VW4RNJ3T88MNXAFTYXJDH3CWN
  role: rescuer
- character: char_0SKYZHPQ0E9B8QKAQGSW56Q2MP
  role: rescued
- character: char_1YSHBR6EMQ1MQX2G6FPJSXK34B
  role: destroyed-memory
- character: char_7AP293AXR57YGHV4444DKCBB4P
  role: helper
causes:
- event_2P639GAQDKX0BHN76141ZB31R5
related_story_points: []
effects: []
---

# Harry Defeats the Basilisk and Destroys the Diary
