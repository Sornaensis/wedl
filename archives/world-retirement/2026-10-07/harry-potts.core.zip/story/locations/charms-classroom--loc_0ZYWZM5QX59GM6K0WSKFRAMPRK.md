---
schema: wedl/v0.3
kind: location
id: loc_0ZYWZM5QX59GM6K0WSKFRAMPRK
title: Charms Classroom
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- flitwick
aliases: []
location_type: classroom
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Charms Classroom

Flitwick's classroom; a routine first-year teaching location.
