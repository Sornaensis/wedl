---
schema: wedl/v0.3
kind: location
id: loc_1NEN1Z27D4FR0EXCGVJ47MSVN8
title: Diagon Alley
domain: setting
status: canonical
tags:
- wizarding-world
- london
aliases: []
location_type: commercial district
links: []
---

# Diagon Alley
