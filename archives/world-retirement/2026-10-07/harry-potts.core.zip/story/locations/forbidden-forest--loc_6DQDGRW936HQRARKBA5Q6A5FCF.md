---
schema: wedl/v0.3
kind: location
id: loc_6DQDGRW936HQRARKBA5Q6A5FCF
title: Forbidden Forest
domain: setting
status: canonical
tags:
- hogwarts
- forest
aliases: []
location_type: forest
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Forbidden Forest

Dangerous woodland beside Hogwarts; site of detention, unicorn attacks, and the Aragog encounter.
