---
schema: wedl/v0.3
kind: location
id: loc_36YFCWAY20FF98HJ4AWJM30WRJ
title: King's Cross Station
domain: setting
status: canonical
tags:
- london
- transport
aliases:
- Platform Nine and Three-Quarters
location_type: railway station
links: []
---

# King's Cross Station
