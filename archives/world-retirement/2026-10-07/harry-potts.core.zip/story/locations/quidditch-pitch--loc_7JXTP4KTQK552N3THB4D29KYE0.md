---
schema: wedl/v0.3
kind: location
id: loc_7JXTP4KTQK552N3THB4D29KYE0
title: Quidditch Pitch
domain: setting
status: canonical
tags:
- hogwarts
- sport
aliases: []
location_type: sports ground
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Quidditch Pitch
