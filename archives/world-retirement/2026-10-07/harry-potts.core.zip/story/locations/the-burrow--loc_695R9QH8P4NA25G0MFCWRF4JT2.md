---
schema: wedl/v0.3
kind: location
id: loc_695R9QH8P4NA25G0MFCWRF4JT2
title: The Burrow
domain: setting
status: canonical
tags:
- weasley
- residence
aliases: []
location_type: residence
links: []
---

# The Burrow
