---
schema: wedl/v0.3
kind: location
id: loc_6BHPPE5ZPF261W9GXABNAC1YY5
title: Restricted Section
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- library
- restricted
aliases: []
location_type: library section
parent: loc_50NQQHHMVN2HDX5RGYC7HPM6N3
links: []
---

# Restricted Section

Controlled library shelves containing advanced and dangerous magical texts.
