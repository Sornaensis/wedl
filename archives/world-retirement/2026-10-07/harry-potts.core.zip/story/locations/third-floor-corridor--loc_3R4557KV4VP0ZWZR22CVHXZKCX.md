---
schema: wedl/v0.3
kind: location
id: loc_3R4557KV4VP0ZWZR22CVHXZKCX
title: Third-Floor Corridor
domain: setting
status: canonical
tags:
- hogwarts
- restricted
- philosopher-stone
aliases: []
location_type: corridor
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Third-Floor Corridor

Restricted route leading to the protections around the Philosopher's Stone.
