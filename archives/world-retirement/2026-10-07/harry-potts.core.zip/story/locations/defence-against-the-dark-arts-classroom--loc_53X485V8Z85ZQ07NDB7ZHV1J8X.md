---
schema: wedl/v0.3
kind: location
id: loc_53X485V8Z85ZQ07NDB7ZHV1J8X
title: Defence Against the Dark Arts Classroom
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- quirrell
- lockhart
aliases:
- DADA classroom
location_type: classroom
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Defence Against the Dark Arts Classroom

Quirrell teaches here in year one; Lockhart occupies it in year two.
