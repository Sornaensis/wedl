---
schema: wedl/v0.3
kind: location
id: loc_50NQQHHMVN2HDX5RGYC7HPM6N3
title: Hogwarts Library
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- research
aliases:
- Library
location_type: library
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Hogwarts Library

Primary research location for the trio's investigations.
