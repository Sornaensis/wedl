---
schema: wedl/v0.3
kind: location
id: loc_6FWCZHN05Q90ZSPND76C3TWN1H
title: Privet Drive
domain: setting
status: canonical
tags:
- surrey
- muggle-world
aliases:
- Number Four
location_type: residence
links: []
---

# Privet Drive
