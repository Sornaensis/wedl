---
schema: wedl/v0.3
kind: location
id: loc_3NJZJN69HVCAPZ4H4RCN4CA40F
title: Transfiguration Classroom
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- mcgonagall
aliases: []
location_type: classroom
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Transfiguration Classroom

McGonagall's classroom and a regular first-year teaching location.
