---
schema: wedl/v0.3
kind: location
id: loc_3FT9V8BJBM3JC4HZJ9EY43R59X
title: Second-Floor Corridor
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- chamber-of-secrets
- petrification
aliases: []
location_type: corridor
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Second-Floor Corridor

Area associated with the first Chamber message and Mrs Norris's Petrification.
