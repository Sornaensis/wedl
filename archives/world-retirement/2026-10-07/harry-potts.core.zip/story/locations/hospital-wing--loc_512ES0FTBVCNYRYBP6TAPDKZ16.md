---
schema: wedl/v0.3
kind: location
id: loc_512ES0FTBVCNYRYBP6TAPDKZ16
title: Hospital Wing
domain: setting
status: canonical
tags:
- hogwarts
- medical
aliases: []
location_type: infirmary
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Hospital Wing

School infirmary; the Petrified victims are held here until the Mandrake restorative is ready.
