---
schema: wedl/v0.3
kind: location
id: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
title: Hogwarts Castle
domain: setting
status: canonical
tags:
- school
- scotland
aliases:
- Hogwarts
location_type: school
links: []
---

# Hogwarts Castle

Seven-year magical boarding school; the setting for both books.
