---
schema: wedl/v0.3
kind: location
id: loc_4NPBE4RK08T1Q7QA4F8DXCF964
title: Chamber of Secrets
domain: setting
status: canonical
tags:
- hogwarts
- slytherin
- hidden
aliases:
- The Chamber
location_type: underground chamber
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Chamber of Secrets

Slytherin's sealed underground chamber; it houses the basilisk and Tom Riddle's diary climax.
