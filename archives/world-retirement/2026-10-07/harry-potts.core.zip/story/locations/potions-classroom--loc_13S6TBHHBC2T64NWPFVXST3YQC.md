---
schema: wedl/v0.3
kind: location
id: loc_13S6TBHHBC2T64NWPFVXST3YQC
title: Potions Classroom
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- dungeons
- snape
aliases: []
location_type: classroom
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Potions Classroom

Snape's dungeon classroom; a source of Harry's suspicion in book one.
