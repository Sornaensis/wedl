---
schema: wedl/v0.3
kind: location
id: loc_1VH2FRNGMCP03VX3V3DACYP21F
title: First-Floor Corridor
domain: setting.hogwarts
status: canonical
tags:
- hogwarts
- troll
aliases: []
location_type: corridor
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# First-Floor Corridor

Location of the Halloween troll encounter.
