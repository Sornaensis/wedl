---
schema: wedl/v0.3
kind: location
id: loc_41NMJCQNZHZAKYVTVZ09JP30AV
title: Gryffindor Tower
domain: setting
status: canonical
tags:
- hogwarts
- gryffindor
aliases:
- Gryffindor common room
location_type: dormitory
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Gryffindor Tower

Harry, Ron, Hermione, and Neville's residential base.
