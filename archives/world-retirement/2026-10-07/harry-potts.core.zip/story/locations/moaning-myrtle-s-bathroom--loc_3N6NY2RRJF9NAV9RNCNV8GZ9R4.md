---
schema: wedl/v0.3
kind: location
id: loc_3N6NY2RRJF9NAV9RNCNV8GZ9R4
title: Moaning Myrtle's Bathroom
domain: setting
status: canonical
tags:
- hogwarts
- chamber-of-secrets
aliases:
- Girls' bathroom
location_type: bathroom
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Moaning Myrtle's Bathroom

Abandoned bathroom containing the entrance to the Chamber of Secrets.
