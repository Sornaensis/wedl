---
schema: wedl/v0.3
kind: location
id: loc_0P0CEA5RV9G4KCRFKQ87QMHYFA
title: Great Hall
domain: setting
status: canonical
tags:
- hogwarts
aliases: []
location_type: hall
parent: loc_5Q2ZYAJC1WYANEEBZ8FHHQYGD3
links: []
---

# Great Hall

Dining hall, Sorting site, and gathering place for school-wide announcements.
