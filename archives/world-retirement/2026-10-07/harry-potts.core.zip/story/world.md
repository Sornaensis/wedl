---
schema: wedl/v0.3
kind: world
id: world_01M0RB7ZV70EFZDA622R0T5C4K
title: 'Harry Potter: Books One and Two'
domain: world
status: canonical
tags:
- harry-potter
- books-one-two
- structured-reference
aliases:
- Harry Potter 1-2
default_timeline: main
timelines:
- id: main
  label: Main chronology
state_keys:
  character:
    location:
      type: entity
      entity_kind: location
    condition:
      type: string
  object:
    holder:
      type: entity
      entity_kind: character
      exclusive_group: placement
    location:
      type: entity
      entity_kind: location
      exclusive_group: placement
    container:
      type: entity
      entity_kind: object
      exclusive_group: placement
    condition:
      type: string
relationship_metrics:
  trust:
    minimum: -1.0
    maximum: 1.0
    default: 0.0
  affinity:
    minimum: -1.0
    maximum: 1.0
    default: 0.0
  fear:
    minimum: 0.0
    maximum: 1.0
    default: 0.0
  respect:
    minimum: -1.0
    maximum: 1.0
    default: 0.0
embedding_policy:
  provider: lsa
  model: wedl-lsa-v1
  dimensions: 192
  max_features: 8192
compilation_policy:
  default_profile: hybrid
  retrieval:
    fts_candidate_limit: 120
    vector_candidate_limit: 120
    hybrid_fts_weight: 1.0
    hybrid_vector_weight: 1.0
    hybrid_rrf_k: 60.0
context_policy:
  default_budget_characters: 8000
  default_max_items: 24
provenance: eyJhY3RvciI6ImxvY2FsOndlZGwiLCJjb21tYW5kIjoicmVwby5pbml0IiwiZ2VuZXJhdG9yIjoid2VkbC8wLjYuMCIsInBhcmVudCI6IjAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAiLCJ0eCI6InR4XzAxTTBSQjdaVjdKNldCOTVHSjVCNFdXSkEzIiwidiI6MX0
---

# Harry Potter: Books One and Two
